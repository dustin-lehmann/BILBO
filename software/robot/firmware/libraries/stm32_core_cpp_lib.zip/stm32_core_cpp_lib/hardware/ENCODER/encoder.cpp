/*
 * encoder.cpp
 *
 *  Created on: May 26, 2024
 *      Author: Dustin Lehmann
 */




