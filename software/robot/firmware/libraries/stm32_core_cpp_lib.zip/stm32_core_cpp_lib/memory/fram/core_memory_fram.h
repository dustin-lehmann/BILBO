/*
 * core_memory_fram.h
 *
 *  Created on: Jul 6, 2022
 *      Author: Dustin Lehmann
 */

#ifndef CORE_MEMORY_FRAM_CORE_MEMORY_FRAM_H_
#define CORE_MEMORY_FRAM_CORE_MEMORY_FRAM_H_

#include "stm32h7xx_hal.h"


class core_memory_FRAM {

};



#endif /* CORE_MEMORY_FRAM_CORE_MEMORY_FRAM_H_ */
