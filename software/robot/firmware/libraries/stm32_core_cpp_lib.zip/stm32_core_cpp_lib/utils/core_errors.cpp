/*
 * error.cpp
 *
 *  Created on: Jul 7, 2022
 *      Author: Dustin Lehmann
 */


#include "core_errors.h"

void core_ErrorHandler(int error_id) {
	while(1);
}
